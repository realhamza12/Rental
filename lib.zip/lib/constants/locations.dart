// lib/constants/locations.dart

const List<String> karachiAreas = [
  'DHA',
  'Clifton',
  'Gulshan-e-Iqbal',
  'Nazimabad',
  'PECHS',
];
