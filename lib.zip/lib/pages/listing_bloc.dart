// listing_bloc.dart

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'car_model.dart';
import 'listing_event.dart';
import 'listing_state.dart';

class ListingBloc extends Bloc<ListingEvent, ListingState> {
  ListingBloc() : super(ListingInitial()) {
    on<LoadListings>((event, emit) async {
      emit(ListingLoading());
      try {
        final snapshot =
            await FirebaseFirestore.instance
                .collection('cars')
                .orderBy('createdAt', descending: true)
                .get();

        final cars =
            snapshot.docs.map((doc) => Car.fromFirestore(doc)).toList();
        emit(ListingLoaded(cars: cars));
      } catch (e) {
        emit(ListingError(message: e.toString()));
      }
    });
  }
}
