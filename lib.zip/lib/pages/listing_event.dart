// listing_event.dart

import 'package:equatable/equatable.dart';

abstract class ListingEvent extends Equatable {
  const ListingEvent();

  @override
  List<Object> get props => [];
}

class LoadListings extends ListingEvent {}
