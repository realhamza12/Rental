// list_car_event.dart

import 'package:equatable/equatable.dart';
import 'package:cross_file/cross_file.dart';

abstract class ListCarEvent extends Equatable {
  const ListCarEvent();

  @override
  List<Object?> get props => [];
}

class SubmitCarListing extends ListCarEvent {
  final String carName;
  final double rentalPrice;
  final String location;
  final String transmission;
  final String ownerName;
  final List<XFile> selectedImages;
  final List<Map<String, dynamic>> rules;

  const SubmitCarListing({
    required this.carName,
    required this.rentalPrice,
    required this.location,
    required this.transmission,
    required this.ownerName,
    required this.selectedImages,
    required this.rules,
  });

  @override
  List<Object?> get props => [
    carName,
    rentalPrice,
    location,
    transmission,
    ownerName,
    selectedImages,
    rules,
  ];
}
