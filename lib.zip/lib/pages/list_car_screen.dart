// Updated list_car_screen.dart with BLoC pattern

import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cross_file/cross_file.dart';
import 'car_listing_success_screen.dart';
import 'navigation_helper.dart';
import 'list_car_bloc.dart';
import 'list_car_event.dart';
import 'list_car_state.dart';

class ListCarScreen extends StatefulWidget {
  const ListCarScreen({Key? key}) : super(key: key);

  @override
  State<ListCarScreen> createState() => _ListCarScreenState();
}

class _ListCarScreenState extends State<ListCarScreen> {
  final TextEditingController _carNameController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  final TextEditingController _ownerNameController = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  final ImagePicker _picker = ImagePicker();

  // Form fields
  String _transmission = 'Automatic';
  List<XFile> _selectedImages = [];
  List<Map<String, dynamic>> _rules = [
    {
      'title': 'Valid Driver\'s License',
      'description':
          'Renter must possess a valid driver\'s license. A copy must be submitted before rental begins.',
    },
    {
      'title': 'Minimum Age Requirement',
      'description':
          'Renters must be at least 21 years old. Additional fees may apply for drivers under 25.',
    },
  ];

  // Transmission options
  final List<String> _transmissionOptions = ['Automatic', 'Manual'];

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => ListCarBloc(),
      child: BlocConsumer<ListCarBloc, ListCarState>(
        listener: (context, state) {
          if (state is ListCarSuccess) {
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(
                builder: (context) => const CarListingSuccessScreen(),
              ),
            );
          } else if (state is ListCarError) {
            ScaffoldMessenger.of(
              context,
            ).showSnackBar(SnackBar(content: Text(state.message)));
          }
        },
        builder: (context, state) {
          return Scaffold(
            body: SafeArea(
              child: Column(
                children: [
                  // Header
                  Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16.0,
                      vertical: 8.0,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8.0),
                          decoration: BoxDecoration(
                            color: Colors.grey[800],
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                          child: const Icon(Icons.grid_view, size: 20),
                        ),
                        const Text(
                          'Rental',
                          style: TextStyle(
                            color: Color(0xFFCCFF00),
                            fontFamily: 'BeVietnamPro',
                            fontSize: 24,
                          ),
                        ),
                        const CircleAvatar(
                          radius: 18,
                          backgroundImage: AssetImage(
                            'assets/images/profile.jpg',
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Main content
                  Expanded(
                    child:
                        state is ListCarLoading
                            ? const Center(child: CircularProgressIndicator())
                            : SingleChildScrollView(
                              child: Padding(
                                padding: const EdgeInsets.all(16.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    // Title - Car image removed as requested
                                    const Text(
                                      'List your car today',
                                      style: TextStyle(
                                        fontSize: 24,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                    const SizedBox(height: 20),
                                    const Text(
                                      'It takes ',
                                      style: TextStyle(
                                        fontSize: 18,
                                        color: Colors.white,
                                      ),
                                    ),
                                    const Text(
                                      'less than 2',
                                      style: TextStyle(
                                        fontSize: 18,
                                        color: Color(0xFFCCFF00),
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const Text(
                                      'minutes to list your car !',
                                      style: TextStyle(
                                        fontSize: 18,
                                        color: Colors.white,
                                      ),
                                    ),

                                    const SizedBox(height: 10),

                                    // Note about mandatory fields
                                    const Text(
                                      'note : fields marked with * are mandatory',
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.grey,
                                      ),
                                    ),

                                    const SizedBox(height: 20),

                                    // Form
                                    Form(
                                      key: _formKey,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          // Car Name (Make and Model)
                                          const Text(
                                            '* Car Name (Make and Model):',
                                            style: TextStyle(
                                              fontSize: 16,
                                              color: Colors.white,
                                            ),
                                          ),
                                          TextFormField(
                                            controller: _carNameController,
                                            style: const TextStyle(
                                              color: Colors.white,
                                            ),
                                            decoration: const InputDecoration(
                                              hintText: 'e.g. Toyota Camry',
                                              hintStyle: TextStyle(
                                                color: Colors.grey,
                                                fontSize: 14,
                                              ),
                                              enabledBorder:
                                                  UnderlineInputBorder(
                                                    borderSide: BorderSide(
                                                      color: Colors.grey,
                                                    ),
                                                  ),
                                              focusedBorder:
                                                  UnderlineInputBorder(
                                                    borderSide: BorderSide(
                                                      color: Color(0xFFCCFF00),
                                                    ),
                                                  ),
                                            ),
                                            validator: (value) {
                                              if (value == null ||
                                                  value.isEmpty) {
                                                return 'Please enter car name (make and model)';
                                              }
                                              return null;
                                            },
                                          ),

                                          const SizedBox(height: 16),

                                          // Daily Rental Price
                                          const Text(
                                            '* Daily Rental Price :',
                                            style: TextStyle(
                                              fontSize: 16,
                                              color: Colors.white,
                                            ),
                                          ),
                                          TextFormField(
                                            controller: _priceController,
                                            style: const TextStyle(
                                              color: Colors.white,
                                            ),
                                            decoration: const InputDecoration(
                                              enabledBorder:
                                                  UnderlineInputBorder(
                                                    borderSide: BorderSide(
                                                      color: Colors.grey,
                                                    ),
                                                  ),
                                              focusedBorder:
                                                  UnderlineInputBorder(
                                                    borderSide: BorderSide(
                                                      color: Color(0xFFCCFF00),
                                                    ),
                                                  ),
                                              prefixText: '\$ ',
                                              prefixStyle: TextStyle(
                                                color: Colors.white,
                                              ),
                                            ),
                                            keyboardType: TextInputType.number,
                                            validator: (value) {
                                              if (value == null ||
                                                  value.isEmpty) {
                                                return 'Please enter rental price';
                                              }
                                              if (double.tryParse(value) ==
                                                  null) {
                                                return 'Please enter a valid number';
                                              }
                                              if (double.parse(value) <= 0) {
                                                return 'Price must be greater than zero';
                                              }
                                              return null;
                                            },
                                          ),

                                          const SizedBox(height: 16),

                                          // Location
                                          const Text(
                                            '* Location :',
                                            style: TextStyle(
                                              fontSize: 16,
                                              color: Colors.white,
                                            ),
                                          ),
                                          TextFormField(
                                            controller: _locationController,
                                            style: const TextStyle(
                                              color: Colors.white,
                                            ),
                                            decoration: const InputDecoration(
                                              enabledBorder:
                                                  UnderlineInputBorder(
                                                    borderSide: BorderSide(
                                                      color: Colors.grey,
                                                    ),
                                                  ),
                                              focusedBorder:
                                                  UnderlineInputBorder(
                                                    borderSide: BorderSide(
                                                      color: Color(0xFFCCFF00),
                                                    ),
                                                  ),
                                            ),
                                            validator: (value) {
                                              if (value == null ||
                                                  value.isEmpty) {
                                                return 'Please enter location';
                                              }
                                              return null;
                                            },
                                          ),

                                          const SizedBox(height: 16),

                                          // Transmission
                                          const Text(
                                            '* Transmission (Manual / Automatic)',
                                            style: TextStyle(
                                              fontSize: 16,
                                              color: Colors.white,
                                            ),
                                          ),
                                          DropdownButtonFormField<String>(
                                            value: _transmission,
                                            dropdownColor: Colors.grey[900],
                                            style: const TextStyle(
                                              color: Colors.white,
                                            ),
                                            decoration: const InputDecoration(
                                              enabledBorder:
                                                  UnderlineInputBorder(
                                                    borderSide: BorderSide(
                                                      color: Colors.grey,
                                                    ),
                                                  ),
                                              focusedBorder:
                                                  UnderlineInputBorder(
                                                    borderSide: BorderSide(
                                                      color: Color(0xFFCCFF00),
                                                    ),
                                                  ),
                                            ),
                                            items:
                                                _transmissionOptions.map((
                                                  String value,
                                                ) {
                                                  return DropdownMenuItem<
                                                    String
                                                  >(
                                                    value: value,
                                                    child: Text(value),
                                                  );
                                                }).toList(),
                                            onChanged: (String? newValue) {
                                              setState(() {
                                                _transmission = newValue!;
                                              });
                                            },
                                          ),

                                          const SizedBox(height: 16),

                                          // Owner Name
                                          const Text(
                                            '* Owner Name :',
                                            style: TextStyle(
                                              fontSize: 16,
                                              color: Colors.white,
                                            ),
                                          ),
                                          TextFormField(
                                            controller: _ownerNameController,
                                            style: const TextStyle(
                                              color: Colors.white,
                                            ),
                                            decoration: const InputDecoration(
                                              enabledBorder:
                                                  UnderlineInputBorder(
                                                    borderSide: BorderSide(
                                                      color: Colors.grey,
                                                    ),
                                                  ),
                                              focusedBorder:
                                                  UnderlineInputBorder(
                                                    borderSide: BorderSide(
                                                      color: Color(0xFFCCFF00),
                                                    ),
                                                  ),
                                            ),
                                            validator: (value) {
                                              if (value == null ||
                                                  value.isEmpty) {
                                                return 'Please enter owner name';
                                              }
                                              return null;
                                            },
                                          ),

                                          const SizedBox(height: 24),

                                          // Car Images
                                          const Text(
                                            '* Car Images (at least 2 required):',
                                            style: TextStyle(
                                              fontSize: 16,
                                              color: Colors.white,
                                            ),
                                          ),
                                          const SizedBox(height: 8),

                                          // Image upload buttons
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              const SizedBox(width: 16),
                                            ],
                                          ),

                                          const SizedBox(height: 16),

                                          // Display selected images
                                          const SizedBox(height: 24),

                                          // Submit button
                                          Center(
                                            child: ElevatedButton(
                                              onPressed:
                                                  () => _submitForm(context),
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor: const Color(
                                                  0xFFCCFF00,
                                                ),
                                                foregroundColor: Colors.black,
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                      horizontal: 40,
                                                      vertical: 12,
                                                    ),
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(30),
                                                ),
                                              ),
                                              child: const Text(
                                                'List My Car',
                                                style: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                  ),

                  // Bottom Navigation
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.black,
                      border: Border(
                        top: BorderSide(color: Colors.grey[900]!, width: 1),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        GestureDetector(
                          onTap:
                              () => NavigationHelper.handleBottomNavigation(
                                context,
                                0,
                              ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: const [
                              Icon(Icons.home, color: Colors.grey, size: 24),
                              Text(
                                'home',
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap:
                              () => NavigationHelper.handleBottomNavigation(
                                context,
                                1,
                              ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.compare_arrows,
                                color: Theme.of(context).primaryColor,
                                size: 24,
                              ),
                              Text(
                                'List Car',
                                style: TextStyle(
                                  color: Theme.of(context).primaryColor,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap:
                              () => NavigationHelper.handleBottomNavigation(
                                context,
                                2,
                              ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: const [
                              Icon(
                                Icons.account_circle_outlined,
                                color: Colors.grey,
                                size: 24,
                              ),
                              Text(
                                'account',
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  void _submitForm(BuildContext context) {
    if (!_formKey.currentState!.validate()) return;

    final carName = _carNameController.text.trim();
    final rentalPrice = double.tryParse(_priceController.text.trim()) ?? 0;
    final location = _locationController.text.trim();
    final ownerName = _ownerNameController.text.trim();

    BlocProvider.of<ListCarBloc>(context).add(
      SubmitCarListing(
        carName: carName,
        rentalPrice: rentalPrice,
        location: location,
        transmission: _transmission,
        ownerName: ownerName,
        selectedImages: _selectedImages,
        rules: _rules,
      ),
    );
  }
}
