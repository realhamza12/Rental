// list_car_bloc.dart

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:uuid/uuid.dart';
import 'list_car_event.dart';
import 'list_car_state.dart';

class ListCarBloc extends Bloc<ListCarEvent, ListCarState> {
  ListCarBloc() : super(ListCarInitial()) {
    on<SubmitCarListing>((event, emit) async {
      emit(ListCarLoading());
      try {
        // Upload images to Firebase Storage
        List<String> imageUrls = [];

        for (var image in event.selectedImages) {
          final ref = FirebaseStorage.instance.ref().child(
            'car_images/${DateTime.now().millisecondsSinceEpoch}.jpg',
          );

          final uploadTask = await ref.putData(await image.readAsBytes());
          final url = await uploadTask.ref.getDownloadURL();
          imageUrls.add(url);
        }

        // Save data to Firestore
        String ownerInitials =
            event.ownerName
                .split(' ')
                .map((n) => n.isNotEmpty ? n[0] : '')
                .join();

        String carId = const Uuid().v4();

        Map<String, dynamic> carData = {
          'id': carId,
          'name': event.carName,
          'type': event.transmission,
          'price': event.rentalPrice,
          'rating': 4.5, // Default or hardcoded rating
          'location': event.location,
          'ownerInitials': ownerInitials,
          'ownerName': event.ownerName,
          'images': imageUrls,
          'rules': event.rules,
          'createdAt': FieldValue.serverTimestamp(),
          'transmission': event.transmission,
          'days': 3, // Default value
        };

        await FirebaseFirestore.instance
            .collection('cars')
            .doc(carId)
            .set(carData);

        emit(ListCarSuccess(carId: carId));
      } catch (e) {
        emit(ListCarError(message: 'Failed to list car: $e'));
      }
    });
  }
}
